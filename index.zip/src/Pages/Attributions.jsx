import React from 'react'

function Attributes() {
    return (
        <body>
            <div className="attributes-body">
                <div className="profile-posts">
                    <h1>Attributions</h1>
                        <p><a href="https://www.flaticon.com/free-icons/panda" title="panda icons" rel="noreferrer" target="_blank">Panda icons created by Freepik - Flaticon</a></p>
                        <p><a href="https://www.flaticon.com/free-icons/animals" title="animals icons" rel="noreferrer" target="_blank">Animals icons created by Freepik - Flaticon</a></p>
                        <p><a href="https://www.flaticon.com/free-icons/home" title="home icons" rel="noreferrer" target="_blank">Home icons created by Dave Gandy - Flaticon</a></p>
                        <p><a href="https://www.flaticon.com/free-icons/person" title="person icons" rel="noreferrer" target="_blank">Person icons created by Lizel Arina - Flaticon</a></p>
                        <p><a href="https://www.flaticon.com/free-icons/crown" title="crown icons" rel="noreferrer" target="_blank">Crown icons created by Pixel perfect - Flaticon</a></p> 
                </div>
            </div>
        </body>
      )
}

export default Attributes;