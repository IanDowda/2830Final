import React from "react";
function Section3(){
    return(
        <div className="section">
        <header>
            <h1>Test</h1>
        </header>
        <main>
            <div>
            </div>
        </main>
    </div>
    )
}

export default Section3