import React from "react";

function Ad(){
    return(
        <div className="section">
        <header>
            <h1>Ad</h1>
        </header>
        <main>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"><img src= "IMG/adtest.jpg" alt="AD" style={{ width: '200px', height: 'auto'}}/></a>
        </main>
    </div>
    )
}

export default Ad