import React from "react";
function ProfilePage(){
    return(
        <div>
        <header>
            <h1>Proflepage</h1>
        </header>
        <main>
        </main>
    </div>
    
)}

export default ProfilePage