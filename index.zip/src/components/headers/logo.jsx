import React from "react";

function Logo(){
    return(
        <div>
        <header>
            <h1>Logotest</h1>
        </header>
        <main>
        </main>
    </div>
    )
}

export default Logo